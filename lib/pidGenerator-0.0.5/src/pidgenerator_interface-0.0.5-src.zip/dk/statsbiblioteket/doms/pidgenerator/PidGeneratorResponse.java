
package dk.statsbiblioteket.doms.pidgenerator;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for testJasb complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="testJasb">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="test2" type="{http://pidgenerator.doms.statsbiblioteket.dk/}fedoraPid"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "testJasb", propOrder = {
    "test2"
})
@XmlRootElement(name = "pidGeneratorResponse")
public class PidGeneratorResponse {

    @XmlElement(required = true)
    protected String test2;

    /**
     * Gets the value of the test2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTest2() {
        return test2;
    }

    /**
     * Sets the value of the test2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTest2(String value) {
        this.test2 = value;
    }

}
