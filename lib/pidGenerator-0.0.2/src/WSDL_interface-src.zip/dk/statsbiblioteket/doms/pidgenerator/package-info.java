@javax.xml.bind.annotation.XmlSchema(namespace = "http://pidgenerator.doms.statsbiblioteket.dk/")
package dk.statsbiblioteket.doms.pidgenerator;
